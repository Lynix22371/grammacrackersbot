package com.grammacrackers.chatpilot.tasks;

import com.grammacrackers.chatpilot.ChatPilotClient;
import com.grammacrackers.chatpilot.ChatPilotMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;

/**
 * Sleep task. Available only when chat votes for it during a night-time
 * vote window. Walks to the saved home bed, right-clicks it, and waits
 * for morning. The auto-bed-tracking in SessionTicker will pick up the
 * bed position the moment grandma sleeps in any new bed, so this task
 * always uses the most recently used bed.
 *
 * v1.2.2 force-sleep flow:
 *   The vanilla "monsters within 8 blocks" check used to make the bot loop
 *   on the bed forever during long mob nights. We now detect that situation
 *   (no isSleeping() after ENTER_TIMEOUT_SECONDS of right-clicking) and
 *   force it through by flipping difficulty to peaceful. Peaceful instantly
 *   despawns every hostile entity server-side, so the next bed click
 *   succeeds. As soon as the bot is confirmed sleeping, we restore the
 *   prior difficulty so the rest of the world keeps working normally.
 *
 *   Requires Grandma's account to have op (or cheats enabled in
 *   single-player). If she doesn't, the difficulty command is rejected
 *   silently and the task gives up cleanly after the FORCE_RETRY window.
 *   No game-state corruption either way: savedDifficulty tracks whether we
 *   actually changed the world and only restores if we did.
 *
 * Stages:
 *   WALK_TO_BED  - Baritone path to the bed coordinates
 *   ENTER_BED    - right-click the bed once close enough; retry until accepted
 *                  or until the entry timeout fires
 *   FORCE_WAIT   - difficulty peaceful was sent; wait for the server to
 *                  process it and despawn hostiles before retrying
 *   FORCE_RETRY  - try the bed again under peaceful; on success, jump to
 *                  SLEEPING (which restores difficulty)
 *   SLEEPING     - wait for morning OR for the player to be kicked out.
 *                  Restores difficulty if we changed it.
 */
public class SleepTask implements Task {

    private enum Stage { WALK_TO_BED, ENTER_BED, FORCE_WAIT, FORCE_RETRY, SLEEPING, DONE }

    /** Hard timeout in case nothing works (no bed, server unreachable, etc.). */
    private static final int TASK_TIMEOUT_SECONDS = 90;
    /** Seconds of right-clicking before we decide to force-sleep. Was 20s. */
    private static final int ENTER_TIMEOUT_SECONDS = 12;
    /** Ticks between sending /difficulty peaceful and the next bed click. */
    private static final int FORCE_WAIT_TICKS = 25;
    /** Seconds to keep retrying under peaceful before giving up entirely. */
    private static final int FORCE_RETRY_TIMEOUT_SECONDS = 15;
    /** How long to wait in SLEEPING before forcing finish even if not morning. */
    private static final int SLEEP_TIMEOUT_SECONDS = 30;

    private Stage stage = Stage.WALK_TO_BED;
    private int   stageStartTick;
    private int   taskStartTick;
    private boolean savedForCombat;

    /**
     * Non-null only if we changed the world's difficulty to peaceful and
     * still owe a restore. Cleared when the restore command is sent. If the
     * restore fails it's reinstated so we can retry on a later tick.
     */
    private Difficulty savedDifficulty;
    /** True after we've fired the force-sleep path once; we don't loop on it. */
    private boolean    forceAttempted;

    @Override public String displayName() { return "Going to sleep"; }
    @Override public String id() { return "sleep"; }

    @Override
    public void start() {
        taskStartTick  = clientTick();
        stageStartTick = clientTick();
        BlockPos bed = ChatPilotClient.HOME.getBedPos();
        if (bed == null) {
            ChatPilotMod.LOGGER.info("[ChatPilot] Sleep task: no bed set, finishing");
            stage = Stage.DONE;
            return;
        }
        ChatPilotClient.BARITONE.hardReset();
        ChatPilotClient.BARITONE.gotoNear(bed, 2);
    }

    @Override
    public boolean tick() {
        var mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return false;

        // Hard task timeout
        if (clientTick() - taskStartTick > TASK_TIMEOUT_SECONDS * 20) {
            ChatPilotMod.LOGGER.info("[ChatPilot] Sleep task hard-timeout, finishing");
            restoreDifficultyIfNeeded(mc);
            return true;
        }

        BlockPos bed = ChatPilotClient.HOME.getBedPos();
        if (bed == null) {
            restoreDifficultyIfNeeded(mc);
            return true;
        }

        switch (stage) {
            case WALK_TO_BED -> {
                if (mc.player.getBlockPos().getSquaredDistance(bed) < 9 || ticksInStage() > 20 * 60) {
                    ChatPilotClient.BARITONE.hardReset();
                    enterStage(Stage.ENTER_BED);
                }
            }
            case ENTER_BED -> {
                if (mc.player.isSleeping()) {
                    enterStage(Stage.SLEEPING);
                    break;
                }
                if (ticksInStage() > ENTER_TIMEOUT_SECONDS * 20) {
                    if (!forceAttempted) {
                        forceAttempted = true;
                        attemptForceSleep(mc);
                        enterStage(Stage.FORCE_WAIT);
                        break;
                    }
                    ChatPilotMod.LOGGER.info("[ChatPilot] Could not enter bed, finishing sleep task");
                    restoreDifficultyIfNeeded(mc);
                    return true;
                }
                if (ticksInStage() % 10 == 0) {
                    rightClickBed(bed);
                }
            }
            case FORCE_WAIT -> {
                if (ticksInStage() >= FORCE_WAIT_TICKS) {
                    rightClickBed(bed);
                    enterStage(Stage.FORCE_RETRY);
                }
            }
            case FORCE_RETRY -> {
                if (mc.player.isSleeping()) {
                    enterStage(Stage.SLEEPING);
                    break;
                }
                if (ticksInStage() > FORCE_RETRY_TIMEOUT_SECONDS * 20) {
                    ChatPilotMod.LOGGER.info("[ChatPilot] Force sleep failed even under peaceful, giving up");
                    restoreDifficultyIfNeeded(mc);
                    return true;
                }
                if (ticksInStage() % 10 == 0) {
                    rightClickBed(bed);
                }
            }
            case SLEEPING -> {
                // Restore difficulty as soon as sleep is confirmed. If the bot
                // wakes before we get to this point (rare), the restore still
                // happens via the task-end paths below.
                restoreDifficultyIfNeeded(mc);

                if (!mc.player.isSleeping()) {
                    ChatPilotMod.LOGGER.info("[ChatPilot] Woke up, sleep task complete");
                    return true;
                }
                if (ticksInStage() > SLEEP_TIMEOUT_SECONDS * 20) {
                    ChatPilotMod.LOGGER.info("[ChatPilot] Sleep timer reached, finishing");
                    return true;
                }
            }
            case DONE -> { return true; }
        }
        return false;
    }

    /**
     * Send /difficulty peaceful and remember the previous setting so we can
     * restore it once the bot is sleeping. If the world is already peaceful
     * we don't record anything to restore (peaceful is the user's choice).
     */
    private void attemptForceSleep(MinecraftClient mc) {
        if (mc.world == null || mc.player == null || mc.player.networkHandler == null) return;
        Difficulty current = mc.world.getDifficulty();
        if (current != Difficulty.PEACEFUL) {
            savedDifficulty = current;
        }
        ChatPilotMod.LOGGER.info("[ChatPilot] Sleep blocked by mobs, forcing via /difficulty peaceful (was {})",
            current);
        try {
            mc.player.networkHandler.sendChatCommand("difficulty peaceful");
        } catch (Throwable t) {
            ChatPilotMod.LOGGER.warn("[ChatPilot] /difficulty peaceful command failed", t);
        }
    }

    /**
     * Restore the saved difficulty if we changed it. Called on sleep
     * confirmation, task end, combat start, and cancel. If the restore
     * itself throws, we keep savedDifficulty around so a later tick can
     * retry instead of the world being left peaceful indefinitely.
     */
    private void restoreDifficultyIfNeeded(MinecraftClient mc) {
        if (savedDifficulty == null) return;
        Difficulty toRestore = savedDifficulty;
        savedDifficulty = null;
        ChatPilotMod.LOGGER.info("[ChatPilot] Restoring difficulty to {}", toRestore);
        try {
            if (mc != null && mc.player != null && mc.player.networkHandler != null) {
                mc.player.networkHandler.sendChatCommand("difficulty " + toRestore.getName());
            }
        } catch (Throwable t) {
            ChatPilotMod.LOGGER.warn("[ChatPilot] /difficulty {} restore failed; will retry next tick",
                toRestore.getName(), t);
            savedDifficulty = toRestore;
        }
    }

    private void rightClickBed(BlockPos bed) {
        var mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null) return;
        Vec3d eye = mc.player.getEyePos();
        Vec3d hc  = Vec3d.ofCenter(bed);
        double dx = hc.x - eye.x, dy = hc.y - eye.y, dz = hc.z - eye.z;
        double horiz = Math.sqrt(dx*dx + dz*dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horiz));
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
        BlockHitResult hr = new BlockHitResult(hc, Direction.UP, bed, false);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hr);
    }

    private void enterStage(Stage next) {
        stage = next;
        stageStartTick = clientTick();
        ChatPilotMod.LOGGER.info("[ChatPilot] Sleep stage -> {}", next);
    }

    @Override
    public boolean onStuck() {
        ChatPilotClient.BARITONE.hardReset();
        BlockPos bed = ChatPilotClient.HOME.getBedPos();
        if (bed == null) return false;
        if (stage == Stage.WALK_TO_BED) {
            ChatPilotClient.BARITONE.gotoNear(bed, 2);
            return true;
        }
        return false;
    }

    @Override
    public void onCombatStart() {
        savedForCombat = true;
        ChatPilotClient.BARITONE.stop();
        // If we were in peaceful for a force-sleep, restore now so combat
        // plays out under the user's chosen difficulty instead of vanishing
        // the attacker mid-swing.
        var mc = MinecraftClient.getInstance();
        restoreDifficultyIfNeeded(mc);
    }

    @Override
    public void onCombatEnd() {
        if (!savedForCombat) return;
        savedForCombat = false;
        BlockPos bed = ChatPilotClient.HOME.getBedPos();
        if (bed != null && stage == Stage.WALK_TO_BED) {
            ChatPilotClient.BARITONE.gotoNear(bed, 2);
        }
    }

    @Override
    public void cancel() {
        ChatPilotClient.BARITONE.hardReset();
        restoreDifficultyIfNeeded(MinecraftClient.getInstance());
    }

    /* helpers */

    private int ticksInStage() { return clientTick() - stageStartTick; }

    private static int clientTick() {
        return (int) (com.grammacrackers.chatpilot.event.TickClock.now() & 0x7fffffff);
    }
}
